﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TlbImpRuleFileEditor
{
    class TreeNodeConstants
    {
        public const string Condition = "Condition";
        public const string EmptyCondition = "<Empty>";
        public const string Untitled = "Untitled";
        public const string Uninitialized_Value = "<Uninitialized>";
    }
}
