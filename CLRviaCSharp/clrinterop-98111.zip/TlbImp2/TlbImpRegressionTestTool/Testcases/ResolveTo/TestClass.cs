﻿using System;

/// <summary>
/// Summary description for Class1
/// </summary>
public class TestClass
{
	public TestClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}
